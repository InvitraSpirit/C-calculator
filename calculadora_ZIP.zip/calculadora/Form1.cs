namespace calculadora
{
    public partial class FORM_Calc : Form
    {
        int position = 0;
        int mode = 0;
        double valor = 0;
        double[] valores = new double[2];
        string valor_exibido = "0";
        
        public FORM_Calc()
        {
            InitializeComponent();
            if (TXTB_Valor.Text == "")
            {
                TXTB_Valor.Text = valor.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void TXTB_Valor_TextChanged(object sender, EventArgs e)
        {

        }

        private void BTN_1_Click(object sender, EventArgs e)
        {
            if (valor_exibido == "0")
            {
                valor_exibido = "1";
            }
            else
            {
                valor_exibido += "1";
            }
            valor = Double.Parse(valor_exibido);
            valores[position] = valor;
            TXTB_Valor.Text += valor_exibido;
        }
        private void BTN_2_Click_1(object sender, EventArgs e)
        {
            if (valor_exibido == "0")
            {
                valor_exibido = "2";
            }
            else
            {
                valor_exibido += "2";
            }
            valor = Double.Parse(valor_exibido);
            valores[position] = valor;
            TXTB_Valor.Text = valor_exibido;
        }

        private void BTN_Clear_Click(object sender, EventArgs e)
        {
            valor_exibido = "0";
            TXTB_Valor.Text = valor_exibido;
            valores[0] = 0;
            valores[1] = 0;
            mode = 0;
            position = 0;
        }

        private void BTN_3_Click(object sender, EventArgs e)
        {
            if (valor_exibido == "0")
            {
                valor_exibido = "3";
            }
            else
            {
                valor_exibido += "3";
            }
            valor = Double.Parse(valor_exibido);
            valores[position] = valor;
            TXTB_Valor.Text = valor_exibido;
        }

        private void BTN_4_Click(object sender, EventArgs e)
        {
            if (valor_exibido == "0")
            {
                valor_exibido = "4";
            }
            else
            {
                valor_exibido += "4";
            }
            valor = Double.Parse(valor_exibido);
            valores[position] = valor;
            TXTB_Valor.Text = valor_exibido;
        }

        private void BTN_5_Click(object sender, EventArgs e)
        {
            if (valor_exibido == "0")
            {
                valor_exibido = "5";
            }
            else
            {
                valor_exibido += "5";
            }
            valor = Double.Parse(valor_exibido);
            valores[position] = valor;
            TXTB_Valor.Text = valor_exibido;
        }

        private void BTN_6_Click(object sender, EventArgs e)
        {
            if (valor_exibido == "0")
            {
                valor_exibido = "6";
            }
            else
            {
                valor_exibido += "6";
            }
            valor = Double.Parse(valor_exibido);
            valores[position] = valor;
            TXTB_Valor.Text = valor_exibido;
        }

        private void BTN_7_Click(object sender, EventArgs e)
        {
            if (valor_exibido == "0")
            {
                valor_exibido = "7";
            }
            else
            {
                valor_exibido += "7";
            }
            valor = Double.Parse(valor_exibido);
            valores[position] = valor;
            TXTB_Valor.Text = valor_exibido;
        }

        private void BTN_8_Click(object sender, EventArgs e)
        {
            if (valor_exibido == "0")
            {
                valor_exibido = "8";
            }
            else
            {
                valor_exibido += "8";
            }
            valor = Double.Parse(valor_exibido);
            valores[position] = valor;
            TXTB_Valor.Text = valor_exibido;
        }

        private void BTN_9_Click(object sender, EventArgs e)
        {
            if (valor_exibido == "0")
            {
                valor_exibido = "9";
            }
            else
            {
                valor_exibido += "9";
            }
            valor = Double.Parse(valor_exibido);
            valores[position] = valor;
            TXTB_Valor.Text = valor_exibido;
        }

        private void BTN_0_Click_1(object sender, EventArgs e)
        {
            if (TXTB_Valor.Text != "0")
            {
                valor_exibido += "0";
                valor = Double.Parse(valor_exibido);
            }
            valores[position] = valor;
            TXTB_Valor.Text = valor_exibido;
        }

        private void BTN_Op_Soma_Click(object sender, EventArgs e)
        {
            valor_exibido = "";
            TXTB_Valor.Text += " + ";
            position = 1;
            mode = 1;
        }

        private void BTN_Op_Sub_Click(object sender, EventArgs e)
        {
            valor_exibido = "";
            TXTB_Valor.Text += " - ";
            position = 1;
            mode = 2;
        }

        private void BTN_Op_Mult_Click(object sender, EventArgs e)
        {
            valor_exibido = "";
            TXTB_Valor.Text += " x ";
            position = 1;
            mode = 3;
        }

        private void BTN_Op_Div_Click(object sender, EventArgs e)
        {
            valor_exibido = "";
            TXTB_Valor.Text += " / ";
            position = 1;
            mode = 4;
        }

        private void BTN_Op_Igual_Click(object sender, EventArgs e)
        {
            switch (mode){
                case 1:
                    valor = valores[0] + valores[1];
                    break;
                case 2:
                    valor = valores[0] - valores[1];
                    break;
                case 3:
                    valor = valores[0] * valores[1];
                    break;
                case 4:
                    valor = valores[0] / valores[1];
                    break;
            }
            valores[0] = valor;
            valores[1] = 0;
            TXTB_Valor.Text = Convert.ToString(valor);
            valor = 0;
            position = 0;
        }
    }
}
