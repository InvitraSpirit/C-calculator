﻿namespace calculadora
{
    partial class FORM_Calc
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            BTN_1 = new Button();
            BTN_2 = new Button();
            BTN_3 = new Button();
            BTN_6 = new Button();
            BTN_5 = new Button();
            BTN_4 = new Button();
            BTN_9 = new Button();
            BTN_8 = new Button();
            BTN_7 = new Button();
            BTN_0 = new Button();
            BTN_Op_Igual = new Button();
            BTN_Op_Soma = new Button();
            BTN_Op_Sub = new Button();
            BTN_Op_Mult = new Button();
            BTN_Op_Div = new Button();
            TXTB_Valor = new TextBox();
            BTN_Clear = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 12);
            label1.Name = "label1";
            label1.Size = new Size(92, 15);
            label1.TabIndex = 0;
            label1.Text = "CALCULADORA";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Calibri", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(252, 12);
            button1.Name = "button1";
            button1.Size = new Size(50, 50);
            button1.TabIndex = 1;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // BTN_1
            // 
            BTN_1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_1.Location = new Point(10, 100);
            BTN_1.Name = "BTN_1";
            BTN_1.Size = new Size(55, 54);
            BTN_1.TabIndex = 2;
            BTN_1.Text = "1";
            BTN_1.UseVisualStyleBackColor = true;
            BTN_1.Click += BTN_1_Click;
            // 
            // BTN_2
            // 
            BTN_2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_2.Location = new Point(91, 100);
            BTN_2.Name = "BTN_2";
            BTN_2.Size = new Size(55, 54);
            BTN_2.TabIndex = 3;
            BTN_2.Text = "2";
            BTN_2.UseVisualStyleBackColor = true;
            BTN_2.Click += BTN_2_Click_1;
            // 
            // BTN_3
            // 
            BTN_3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_3.Location = new Point(173, 100);
            BTN_3.Name = "BTN_3";
            BTN_3.Size = new Size(55, 54);
            BTN_3.TabIndex = 4;
            BTN_3.Text = "3";
            BTN_3.UseVisualStyleBackColor = true;
            BTN_3.Click += BTN_3_Click;
            // 
            // BTN_6
            // 
            BTN_6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_6.Location = new Point(173, 182);
            BTN_6.Name = "BTN_6";
            BTN_6.Size = new Size(55, 54);
            BTN_6.TabIndex = 7;
            BTN_6.Text = "6";
            BTN_6.UseVisualStyleBackColor = true;
            BTN_6.Click += BTN_6_Click;
            // 
            // BTN_5
            // 
            BTN_5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_5.Location = new Point(91, 182);
            BTN_5.Name = "BTN_5";
            BTN_5.Size = new Size(55, 54);
            BTN_5.TabIndex = 6;
            BTN_5.Text = "5";
            BTN_5.UseVisualStyleBackColor = true;
            BTN_5.Click += BTN_5_Click;
            // 
            // BTN_4
            // 
            BTN_4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_4.Location = new Point(10, 182);
            BTN_4.Name = "BTN_4";
            BTN_4.Size = new Size(55, 54);
            BTN_4.TabIndex = 5;
            BTN_4.Text = "4";
            BTN_4.UseVisualStyleBackColor = true;
            BTN_4.Click += BTN_4_Click;
            // 
            // BTN_9
            // 
            BTN_9.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_9.Location = new Point(173, 267);
            BTN_9.Name = "BTN_9";
            BTN_9.Size = new Size(55, 54);
            BTN_9.TabIndex = 10;
            BTN_9.Text = "9";
            BTN_9.UseVisualStyleBackColor = true;
            BTN_9.Click += BTN_9_Click;
            // 
            // BTN_8
            // 
            BTN_8.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_8.Location = new Point(91, 267);
            BTN_8.Name = "BTN_8";
            BTN_8.RightToLeft = RightToLeft.Yes;
            BTN_8.Size = new Size(55, 54);
            BTN_8.TabIndex = 9;
            BTN_8.Text = "8";
            BTN_8.UseVisualStyleBackColor = true;
            BTN_8.Click += BTN_8_Click;
            // 
            // BTN_7
            // 
            BTN_7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_7.Location = new Point(10, 267);
            BTN_7.Name = "BTN_7";
            BTN_7.Size = new Size(55, 54);
            BTN_7.TabIndex = 8;
            BTN_7.Text = "7";
            BTN_7.UseVisualStyleBackColor = true;
            BTN_7.Click += BTN_7_Click;
            // 
            // BTN_0
            // 
            BTN_0.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_0.Location = new Point(12, 351);
            BTN_0.Name = "BTN_0";
            BTN_0.Size = new Size(55, 54);
            BTN_0.TabIndex = 11;
            BTN_0.Text = "0";
            BTN_0.UseVisualStyleBackColor = true;
            BTN_0.Click += BTN_0_Click_1;
            // 
            // BTN_Op_Igual
            // 
            BTN_Op_Igual.BackColor = Color.Lime;
            BTN_Op_Igual.Font = new Font("Calibri", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_Op_Igual.ForeColor = SystemColors.ControlLightLight;
            BTN_Op_Igual.Location = new Point(91, 351);
            BTN_Op_Igual.Name = "BTN_Op_Igual";
            BTN_Op_Igual.Size = new Size(137, 54);
            BTN_Op_Igual.TabIndex = 12;
            BTN_Op_Igual.Text = "=";
            BTN_Op_Igual.UseVisualStyleBackColor = false;
            BTN_Op_Igual.Click += BTN_Op_Igual_Click;
            // 
            // BTN_Op_Soma
            // 
            BTN_Op_Soma.BackColor = SystemColors.AppWorkspace;
            BTN_Op_Soma.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_Op_Soma.ForeColor = SystemColors.ControlLightLight;
            BTN_Op_Soma.Location = new Point(248, 167);
            BTN_Op_Soma.Name = "BTN_Op_Soma";
            BTN_Op_Soma.Size = new Size(43, 43);
            BTN_Op_Soma.TabIndex = 13;
            BTN_Op_Soma.Text = "+";
            BTN_Op_Soma.TextAlign = ContentAlignment.TopCenter;
            BTN_Op_Soma.UseVisualStyleBackColor = false;
            BTN_Op_Soma.Click += BTN_Op_Soma_Click;
            // 
            // BTN_Op_Sub
            // 
            BTN_Op_Sub.BackColor = SystemColors.AppWorkspace;
            BTN_Op_Sub.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_Op_Sub.ForeColor = SystemColors.ControlLightLight;
            BTN_Op_Sub.Location = new Point(248, 235);
            BTN_Op_Sub.Name = "BTN_Op_Sub";
            BTN_Op_Sub.Size = new Size(43, 43);
            BTN_Op_Sub.TabIndex = 14;
            BTN_Op_Sub.Text = "-";
            BTN_Op_Sub.UseVisualStyleBackColor = false;
            BTN_Op_Sub.Click += BTN_Op_Sub_Click;
            // 
            // BTN_Op_Mult
            // 
            BTN_Op_Mult.BackColor = SystemColors.AppWorkspace;
            BTN_Op_Mult.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_Op_Mult.ForeColor = SystemColors.ControlLightLight;
            BTN_Op_Mult.Location = new Point(248, 299);
            BTN_Op_Mult.Name = "BTN_Op_Mult";
            BTN_Op_Mult.Size = new Size(43, 43);
            BTN_Op_Mult.TabIndex = 15;
            BTN_Op_Mult.Text = "x";
            BTN_Op_Mult.UseVisualStyleBackColor = false;
            BTN_Op_Mult.Click += BTN_Op_Mult_Click;
            // 
            // BTN_Op_Div
            // 
            BTN_Op_Div.BackColor = SystemColors.AppWorkspace;
            BTN_Op_Div.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_Op_Div.ForeColor = SystemColors.ControlLightLight;
            BTN_Op_Div.Location = new Point(248, 362);
            BTN_Op_Div.Name = "BTN_Op_Div";
            BTN_Op_Div.Size = new Size(43, 43);
            BTN_Op_Div.TabIndex = 16;
            BTN_Op_Div.Text = "/";
            BTN_Op_Div.UseVisualStyleBackColor = false;
            BTN_Op_Div.Click += BTN_Op_Div_Click;
            // 
            // TXTB_Valor
            // 
            TXTB_Valor.Font = new Font("Impact", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            TXTB_Valor.Location = new Point(12, 51);
            TXTB_Valor.Name = "TXTB_Valor";
            TXTB_Valor.Size = new Size(225, 33);
            TXTB_Valor.TabIndex = 17;
            TXTB_Valor.TextAlign = HorizontalAlignment.Right;
            TXTB_Valor.TextChanged += TXTB_Valor_TextChanged;
            // 
            // BTN_Clear
            // 
            BTN_Clear.BackColor = SystemColors.AppWorkspace;
            BTN_Clear.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BTN_Clear.ForeColor = SystemColors.ButtonHighlight;
            BTN_Clear.Location = new Point(248, 100);
            BTN_Clear.Name = "BTN_Clear";
            BTN_Clear.Size = new Size(43, 43);
            BTN_Clear.TabIndex = 18;
            BTN_Clear.Text = "AC";
            BTN_Clear.UseVisualStyleBackColor = false;
            BTN_Clear.Click += BTN_Clear_Click;
            // 
            // FORM_Calc
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(325, 450);
            Controls.Add(BTN_Clear);
            Controls.Add(TXTB_Valor);
            Controls.Add(BTN_Op_Div);
            Controls.Add(BTN_Op_Mult);
            Controls.Add(BTN_Op_Sub);
            Controls.Add(BTN_Op_Soma);
            Controls.Add(BTN_Op_Igual);
            Controls.Add(BTN_0);
            Controls.Add(BTN_9);
            Controls.Add(BTN_8);
            Controls.Add(BTN_7);
            Controls.Add(BTN_6);
            Controls.Add(BTN_5);
            Controls.Add(BTN_4);
            Controls.Add(BTN_3);
            Controls.Add(BTN_2);
            Controls.Add(BTN_1);
            Controls.Add(button1);
            Controls.Add(label1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FORM_Calc";
            Text = "CALCULADORA";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private Button BTN_1;
        private Button BTN_2;
        private Button BTN_3;
        private Button BTN_6;
        private Button BTN_5;
        private Button BTN_4;
        private Button BTN_9;
        private Button BTN_8;
        private Button BTN_7;
        private Button BTN_0;
        private Button BTN_Op_Igual;
        private Button BTN_Op_Soma;
        private Button BTN_Op_Sub;
        private Button BTN_Op_Mult;
        private Button BTN_Op_Div;
        private TextBox TXTB_Valor;
        private Button BTN_Clear;
    }
}
